opencv_version = "4.12.0.88"
contrib = True
headless = False
rolling = False
ci_build = True